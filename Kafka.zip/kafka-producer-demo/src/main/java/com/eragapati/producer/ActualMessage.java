package com.eragapati.producer;

import lombok.*;
import org.springframework.stereotype.Component;

@Data
@Builder
@NoArgsConstructor
@EqualsAndHashCode
@AllArgsConstructor
public class ActualMessage {
    private String name;
    private String age;
}
