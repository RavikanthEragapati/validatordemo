const MongoClient = require('mongodb').MongoClient;
const Chance = require('chance');
const assert = require('assert');
const chance = new Chance();

// Connection URL
const url = "mongodb+srv://eragapati:u2HZYW%25VqAuSL3U@rk-cluster.qrpyw.mongodb.net/Groceries?retryWrites=true&w=majority";

// Create a new MongoClient
const client = new MongoClient(url);

async function run() {
  try {
    await client.connect();

    const database = client.db("Groceries");
    const foods = database.collection("groceriesItems");
    var userGuidsArray = [];
    for(let i=0; i< 10; i++)
    {
       userGuidsArray[i] = chance.guid();
    }

    // create an array of documents to insert
    var docs = [];
    var counter = 0;
    for(let i=0; i<10; i++){
      var subject = chance.string({ length: 100 });
      var body = chance.sentence();
      var formatedBody = chance.string({length: 1000})
      var currentDate = new Date();
      var expireDate = new Date();
      expireDate.setDate(expireDate.getDate() - i);
      for(let j =0; j < 10; j++){
        docs[counter] = { _id : chance.integer(),  toUniqueAuthUserID : userGuidsArray[j], subject : subject, body : body, formattedBody : "<div class=\"tbd\"><b>Prefer to talk with someone?</b></div><div class=\"tbd\">Click the Guides Button Below</div>", isRead : false, isDeleted : false, isHighlighted : false, vin : "", notificationMessageType : "EXTERNAL_NOTIFICATION_REQUEST", publisherType : "UNIQUEAUTHENTICATIONID", publisher : userGuidsArray[0], externalMessageType : 20001, metadata : "{\"components\": {\"version\": 1.0,\"actions\": {\"externalLink\": {\"url\": \"https://www.autoshow.ca/\",\"label\": \"Learn More\"}},\"image\": {\"assetLocation\": \"remote\",\n\"small\": \"https://www.fordpass.ca/content/dam/fp_app/message_center/en_ca/fp_torautoshow_en_small.jpg\",\n\"medium\": \"https://www.fordpass.ca/content/dam/fp_app/message_center/en_ca/fp_torautoshow_en_medium.jpg\",\n\"large\": \"https://www.fordpass.ca/content/dam/fp_app/message_center/en_ca/fp_torautoshow_en_large.jpg\"}}}", notificationPriority : "NORMAL", notificationPriorityCode : 1, contentType : "HTML", appGroupIDs : [ "FordAppGroup" ], tag : chance.string({ length: 10 }), isActionRequired : false, providerType : "Message Center", providerID : "2", createdBy : "SYSTEM", createdDate : currentDate, lastModifiedBy : "SYSTEM", lastModifiedDate : currentDate, expirationDate : expireDate };
        counter++;
      }
      console.log(docs.length);

}


    const options = { ordered: true };

    const result = await foods.insertMany(docs, options);
    console.log(`${result.insertedCount} documents were inserted`);
  } finally {
    await client.close();
  }
}
run().catch(console.dir);
